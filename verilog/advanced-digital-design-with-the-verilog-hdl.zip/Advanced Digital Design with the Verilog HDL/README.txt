
1. The models in this release reflect changes made for the revised version of the text released August 2003. These models have not been modified for the newest edition.

2. Testbenches for the models in Chapters 7-11 are included in the zip file.  The remaining testbenches will also be added.  If you need a particular model/testbench that is not included in this release please notify me and I will provide it.

3. Note:  Some compilers are relaxed about requiring a redundant declaration of the size of an array whose size has already been declared by an output statement.  Some of the models in this release have been changed to adhere to the tighter constraint.  If you encounter a model that has not been changed please notify me.

4. In some cases, the file containing the model also contains its testbench.

5. Every effort has been made to ensure that these models are correct.  Please notify me of any errors that you detect.
 
