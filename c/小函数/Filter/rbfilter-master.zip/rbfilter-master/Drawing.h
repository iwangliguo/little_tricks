/******************************************************************************

                                Drawing.h

                Copyright (c) Roger Burghall 2014..2017

******************************************************************************/


#ifndef DRAWINGH
#define DRAWINGH

/*! \file Drawing.h
*/

#define SHOW_XY false

enum DrawMode { Splane, Step, Bode, Realisation } ;

#endif
