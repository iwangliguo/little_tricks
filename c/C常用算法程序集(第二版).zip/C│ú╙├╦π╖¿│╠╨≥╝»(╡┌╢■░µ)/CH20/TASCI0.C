
  #include "tasci.c"
  main()
  { tasci("asci");
  }

